<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mercadopago}prestashop>mercadopago_3ce3662af6cffea8677b4cb92dea4939'] =
'Mercado Pago';
$_MODULE['<{mercadopago}prestashop>mercadopago_b9a2e0f33da43f952a816aa78f78ee2e'] =
'Personaliza la experiencia de pago de tus clientes y convierte tu sitio en una tienda online.';
$_MODULE['<{mercadopago}prestashop>mercadopago_0f379daaee21894a7c6453950658fe8b'] =
'¿Está seguro de que desea desinstalar el módulo?';
$_MODULE['<{mercadopago}prestashop>mercadopago_a88f84d8cb58f8230240e1665058c7ff'] =
'Tienes que habilitar la extensión cURL ';
$_MODULE['<{mercadopago}prestashop>mercadopago_d4423ad419d2bf8911d67aae2710b2bf'] =
'en su servidor para instalar este módulo.';
$_MODULE['<{mercadopago}prestashop>mercadopago_aea84af3b9a9115bf366af2993aafe68'] =
'Transacción en Proceso';
$_MODULE['<{mercadopago}prestashop>mercadopago_5b3f086dfa19e142c8dd3dd4c3248379'] =
'Transacción Terminada';
$_MODULE['<{mercadopago}prestashop>mercadopago_f01f74aabecf111292f9b9e01027ae0c'] =
'Transacción Cancelada';
$_MODULE['<{mercadopago}prestashop>mercadopago_52c8fdd11601ff4aacfacba9cb00f873'] =
'Transacción Rechazada';
$_MODULE['<{mercadopago}prestashop>mercadopago_186177a57ee4cb741ba591e0259e871f'] =
'Transacción Reembolsada';
$_MODULE['<{mercadopago}prestashop>mercadopago_ab74c3411f6f46df16a6c47791be5a1b'] =
'Transacción Chargedback';
$_MODULE['<{mercadopago}prestashop>mercadopago_bf40a1c10d0b4a9cb26a27593226285b'] =
'Transacción en la Mediación';
$_MODULE['<{mercadopago}prestashop>mercadopago_53b4d02529d11ed85eb327d5297ec1ca'] =
'Transacción Pendiente';
$_MODULE['<{mercadopago}prestashop>mercadopago_2b39c27da5542ec1a72d8151ac607cd7'] =
'Transacción Autorizada';
$_MODULE['<{mercadopago}prestashop>mercadopago_3e8bd808fa886bce4b3de20f28870f9d'] =
'Quiero pagar con Mercado Pago sin costo adicional.';
$_MODULE['<{mercadopago}prestashop>mercadopago_f4818b8be3fb0dcad10b46475db2efa1'] =
' Paga con tarjetas de crédito y débito';
$_MODULE['<{mercadopago}prestashop>mercadopago_5edffb5efe684d534217bad198adeece'] =
'Paga con medios de pago en efectivo';
$_MODULE['<{mercadopago}prestashop>homologationsettings_2488dda96f94d5e5d7f227690ed5fabc'] =
'Homologación';
$_MODULE['<{mercadopago}prestashop>abstractsettings_c9cc8cce247e49bae79f15173ce97354'] =
' Guardar';
$_MODULE['<{mercadopago}prestashop>abstractsettings_4d9ac946f92f7211e40671513c72fd09'] =
' Configuración guardada con éxito.';
$_MODULE['<{mercadopago}prestashop>abstractsettings_36ac045205b16f9bb7cd8bb5641e839d'] =
' El tiempo para guardar las preferencias de pago';
$_MODULE['<{mercadopago}prestashop>abstractsettings_81495f3842f92cd64795702e235405e6'] =
' debe ser un número entero.';
$_MODULE['<{mercadopago}prestashop>abstractsettings_93027262f5c97f5faccac9eb7ef7df6d'] =
' Las credenciales no pueden estar vacías y deben ser válidas.';
$_MODULE['<{mercadopago}prestashop>abstractsettings_cbfa2a7c18db32aca0f634532701ee11'] =
' Por favor, completa tus credenciales para activar el módulo.';
$_MODULE['<{mercadopago}prestashop>abstractsettings_0a89ca4eadc203592214129f2355a257'] =
' El descuento debe ser un número entero menor a 100%.';
$_MODULE['<{mercadopago}prestashop>abstractsettings_d13e2a23135def99ea08f9a21eb663a0'] =
' El pago a recibir debe ser un número entero.';
$_MODULE['<{mercadopago}prestashop>standardsettings_263485bdc392a068c22db476bfb5d0f2'] =
'Configuración Básica';
$_MODULE['<{mercadopago}prestashop>standardsettings_49c557074b8d2bdb3ad51b3e0a7de714'] =
'Activar checkout';
$_MODULE['<{mercadopago}prestashop>standardsettings_d8bf0bd06048ac8cb87266046772cd15'] =
'Activa la experiencia de Mercado Pago en el checkout de tu tienda.';
$_MODULE['<{mercadopago}prestashop>standardsettings_4d3d769b812b6faa6b76e1a8abaece2d'] =
'Activa';
$_MODULE['<{mercadopago}prestashop>standardsettings_3cab03c00dbd11bc3569afa0748013f0'] =
'Inactiva';
$_MODULE['<{mercadopago}prestashop>standardsettings_0da8d9a75492046bea7f314521e07cae'] =
' Medios de pago';
$_MODULE['<{mercadopago}prestashop>standardsettings_dd2360b0896865677612fc496a384b2c'] =
'Selecciona los medios de pago disponibles en tu tienda.';
$_MODULE['<{mercadopago}prestashop>standardsettings_011901666e08f84f38252b5321a7d4de'] =
'Habilita los medios de pago disponibles para tus clientes.';
$_MODULE['<{mercadopago}prestashop>standardsettings_4ad84b90f75b593109969f6a67c0e589'] =
'Máximo de cuotas';
$_MODULE['<{mercadopago}prestashop>standardsettings_0e6481ebfe97897129692fc56936e471'] =
'¿Cuál es el máximo de cuotas con las que un cliente puede comprar?';
$_MODULE['<{mercadopago}prestashop>standardsettings_5ef05891c0ce9ae545044e6d83e0966d'] =
'¿Volver a la tienda?';
$_MODULE['<{mercadopago}prestashop>standardsettings_9bf51651de5441f6628f68d3859a857e'] =
'¿Quieres que tu cliente vuelva a la tienda después de finalizar la compra ';
$_MODULE['<{mercadopago}prestashop>standardsettings_5c37fb51921ed01de76b54887c7bad59'] =
'a la tienda después de finalizar la compra?';
$_MODULE['<{mercadopago}prestashop>standardsettings_7f6733fc4902833edb6f6d1a89fb4acc'] =
'Modal checkout';
$_MODULE['<{mercadopago}prestashop>standardsettings_833a9c46c3664a83053f319489b4c238'] =
'Tus clientes accederán al formulario de pagos de Mercado Pago ';
$_MODULE['<{mercadopago}prestashop>standardsettings_6a02c0cb3d450c1e23157b4ef4155a50'] =
'sin salir de tu tienda. Si lo desactivas, ';
$_MODULE['<{mercadopago}prestashop>standardsettings_ae47f9266c75b0b9cf904ce182f9b510'] =
'serán redirigidos a otra página.';
$_MODULE['<{mercadopago}prestashop>standardsettings_deb43872e3df204974c85e5b07ad8576'] =
'Modo binario';
$_MODULE['<{mercadopago}prestashop>standardsettings_65073593c74f39e8b77174346432937e'] =
'Aprueba o rechaza pagos al instante y de forma ';
$_MODULE['<{mercadopago}prestashop>standardsettings_cef6266789eeb18008a67056a56d680c'] =
'automática, sin estados pendientes o en revisión. ¿Quieres que lo activemos?';
$_MODULE['<{mercadopago}prestashop>standardsettings_14e34536b7eea32e8a7e021bea1b9b91'] =
' Activarlo puede afectar a la prevención de fraude. ';
$_MODULE['<{mercadopago}prestashop>standardsettings_e7369d7d7500eb4804b08192ab2b1444'] =
'Déjalo inactivo para que ';
$_MODULE['<{mercadopago}prestashop>standardsettings_f18f9cbe68138db2d541dd171101fb35'] =
'podamos cuidar tus cobros.';
$_MODULE['<{mercadopago}prestashop>standardsettings_e158df26c6c5fa5329868a48ab2e54ee'] =
'horas sin actividad';
$_MODULE['<{mercadopago}prestashop>standardsettings_f4baa4850222eacc72d4f217fd03e252'] =
'Cancela las preferencias de pago luego de ';
$_MODULE['<{mercadopago}prestashop>standardsettings_941254e31637b81ac1008e6eb1861c93'] =
'Durante este tiempo guardaremos la preferencia de pago';
$_MODULE['<{mercadopago}prestashop>standardsettings_4476880111ab525b0ef3cfe9173c40ba'] =
' para no volver a pedirle los datos a tu cliente. ';
$_MODULE['<{mercadopago}prestashop>standardsettings_42b26ebeb795fcdfdd3d59e3f301970d'] =
'Una vez transcurrido se borrará automáticamente.';
$_MODULE['<{mercadopago}prestashop>ratingsettings_5ecdf7c8fed5fa55b341b963ae70790f'] =
'¡Gracias por calificarnos! ';
$_MODULE['<{mercadopago}prestashop>credentialssettings_2daf1cb573c2c61422faf64610cf9402'] =
'Credenciales';
$_MODULE['<{mercadopago}prestashop>credentialssettings_756d97bb256b8580d4d71ee0c547804e'] =
'Producción';
$_MODULE['<{mercadopago}prestashop>credentialssettings_ebc4608a47aa08cb533d928e0259f1df'] =
'Elige “SÍ” solo cuando estés listo para vender. ';
$_MODULE['<{mercadopago}prestashop>credentialssettings_6087b8439a7036bff644affc8784da4b'] =
'Cambia a NO para activar ';
$_MODULE['<{mercadopago}prestashop>credentialssettings_3bc591c82367247890499e4b021a933e'] =
'el entorno de pruebas Sandbox.';
$_MODULE['<{mercadopago}prestashop>credentialssettings_3cab03c00dbd11bc3569afa0748013f0'] =
'Inactivar';
$_MODULE['<{mercadopago}prestashop>credentialssettings_4d3d769b812b6faa6b76e1a8abaece2d'] =
'Activar';
$_MODULE['<{mercadopago}prestashop>credentialssettings_cd00f38c17c8d33b4ee0141caed3c806'] =
'Cargar credenciales';
$_MODULE['<{mercadopago}prestashop>credentialssettings_22cea83454a1f571a8935118c4d423f6'] =
'Buscar mis credenciales';
$_MODULE['<{mercadopago}prestashop>credentialssettings_37c5b6e7c4291021b6100a6754ae7ffe'] =
'Public Key';
$_MODULE['<{mercadopago}prestashop>credentialssettings_5bc7ab301074148dc708229c5ad54fc6'] =
'Access token';
$_MODULE['<{mercadopago}prestashop>credentialssettings_f9465576c2b33512983a54a95bad3210'] =
'Configuración guardada con éxito. Ahora puedes configurar el módulo.';
$_MODULE['<{mercadopago}prestashop>customsettings_263485bdc392a068c22db476bfb5d0f2'] =
'Configuración Básica';
$_MODULE['<{mercadopago}prestashop>customsettings_49c557074b8d2bdb3ad51b3e0a7de714'] =
' Activar checkout';
$_MODULE['<{mercadopago}prestashop>customsettings_d8bf0bd06048ac8cb87266046772cd15'] =
'Activa la opción de pagos con tarjetas de débito y crédito en tu tienda.';
$_MODULE['<{mercadopago}prestashop>customsettings_4d3d769b812b6faa6b76e1a8abaece2d'] =
'Activa';
$_MODULE['<{mercadopago}prestashop>customsettings_3cab03c00dbd11bc3569afa0748013f0'] =
'Inactiva';
$_MODULE['<{mercadopago}prestashop>customsettings_deb43872e3df204974c85e5b07ad8576'] =
'Modo binario';
$_MODULE['<{mercadopago}prestashop>customsettings_880bb5685c2e7ef3c65fe0aad31a4dae'] =
'Aprueba o rechaza pagos al instante y de forma automática, ';
$_MODULE['<{mercadopago}prestashop>customsettings_4c0985e3f8194a2415269103fa9a104d'] =
'sin estados pendientes o en revisión. ¿Quieres que lo activemos?';
$_MODULE['<{mercadopago}prestashop>customsettings_679555bbde4dbc004d33b03a55d4a764'] =
'Activarlo puede afectar a la prevención de fraude.';
$_MODULE['<{mercadopago}prestashop>customsettings_237779dcb8689068ce4d9abdad8c6ce5'] =
' Déjalo inactivo para que podamos ';
$_MODULE['<{mercadopago}prestashop>customsettings_1a9640e57cd90969114812b5bf0c27ef'] =
'cuidar tus cobros.';
$_MODULE['<{mercadopago}prestashop>customsettings_5143ec2136ffd545e7aafcc9c0ce50f5'] =
'Descuento por compra';
$_MODULE['<{mercadopago}prestashop>customsettings_f2a22ca66322e56b52de81d06834c1e4'] =
'Ofrece un descuento especial para alentar a que tus ';
$_MODULE['<{mercadopago}prestashop>customsettings_474aceb7275c706995d816dc90bdf45d'] =
'clientes realicen la compra con Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>ticketsettings_c2adc2174b4cd2fd168bc5de3f1d1c48'] =
'No es posible deshabilitar ';
$_MODULE['<{mercadopago}prestashop>ticketsettings_87fb0447a4e4615a6c2f40ec2154fc1c'] =
'todos los medios de pago para el Ticket Checkout.';
$_MODULE['<{mercadopago}prestashop>storesettings_80a11d2a54a677f6fadd9c041c0d6b98'] =
'Información de tu tienda';
$_MODULE['<{mercadopago}prestashop>storesettings_49ee3087348e8d44e1feda1917443987'] =
'Nombre';
$_MODULE['<{mercadopago}prestashop>storesettings_9f122d1b74cc2730551f41a39f024633'] =
'Este nombre aparecerá en la factura de tus clientes.';
$_MODULE['<{mercadopago}prestashop>storesettings_3adbdb3ac060038aa0e6e6c138ef9873'] =
'Categoría';
$_MODULE['<{mercadopago}prestashop>storesettings_4182e847f507c9ea3adc3c5aa742ba66'] =
'¿A qué categoría pertenecen tus productos? ';
$_MODULE['<{mercadopago}prestashop>storesettings_a125e14c06e3cdcf245efc8fbf61d6d7'] =
'Elige la que mejor los caracteriza ';
$_MODULE['<{mercadopago}prestashop>storesettings_8f69960af1e12c180f1a274210f219ad'] =
'(elige “otro” si tu producto es demasiado específico).';
$_MODULE['<{mercadopago}prestashop>storesettings_67cb4db65a7c5f0878b2d5aa20db71ba'] =
'Integrator ID';
$_MODULE['<{mercadopago}prestashop>storesettings_67a10b694ba920e2ad489d7637b78db4'] =
'Con este número identificamos todas tus transacciones ';
$_MODULE['<{mercadopago}prestashop>storesettings_4a792eeaee7dfa3703cfb05e4940ad1b'] =
'y sabemos cuántas ventas procesamos con tu cuenta. ';
$_MODULE['<{mercadopago}prestashop>localizationsettings_369686331c93d55e587441143ccdf427'] =
'Localización';
$_MODULE['<{mercadopago}prestashop>localizationsettings_f64be5eef68442a8f50cf535b92ad3e4'] =
'País:';
$_MODULE['<{mercadopago}prestashop>localizationsettings_bdaea8d8b9968a9c9ec57e2ebf37d9f8'] =
'Selecciona el país en el que opera tu cuenta de Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>localizationsettings_f9465576c2b33512983a54a95bad3210'] =
'Configuración guardada con éxito. Ahora puedes configurar el módulo.';
$_MODULE['<{mercadopago}prestashop>localizationsettings_8b144ffc87beff564884b1c190275539'] =
'Selecciona el país';
$_MODULE['<{mercadopago}prestashop>localizationsettings_3536be57ce0713954e454ae6c53ec023'] =
'Argentina';
$_MODULE['<{mercadopago}prestashop>localizationsettings_42537f0fb56e31e20ab9c2305752087d'] =
'Brasil';
$_MODULE['<{mercadopago}prestashop>localizationsettings_2e6507f70a9cc26fb50f5fd82a83c7ef'] =
'Chile';
$_MODULE['<{mercadopago}prestashop>localizationsettings_ef3388cc5659bccb742fb8af762f1bfd'] =
'Colombia';
$_MODULE['<{mercadopago}prestashop>localizationsettings_8dbb07a18d46f63d8b3c8994d5ccc351'] =
'Mexico';
$_MODULE['<{mercadopago}prestashop>localizationsettings_84c8fa2341f7d052a1ee3a36ff043798'] =
'Perú';
$_MODULE['<{mercadopago}prestashop>localizationsettings_75497a22409db78dcc52c291e078bc10'] =
'Uruguay';
$_MODULE['<{mercadopago}prestashop>localizationsettings_e95294b730f61c8175550ec244bfcb50'] =
'Venezuela';
$_MODULE['<{mercadopago}prestashop>ticketsettings_263485bdc392a068c22db476bfb5d0f2'] =
'Configuración Básica';
$_MODULE['<{mercadopago}prestashop>ticketsettings_7d7ad4775c720af6567f212e5e4ec012'] =
'Activar Checkout de pagos presenciales';
$_MODULE['<{mercadopago}prestashop>ticketsettings_c464d6c07376bc896eaef0a39673154a'] =
'Activa la opción de pagos presenciales en tu tienda.';
$_MODULE['<{mercadopago}prestashop>ticketsettings_4d3d769b812b6faa6b76e1a8abaece2d'] =
'Activa';
$_MODULE['<{mercadopago}prestashop>ticketsettings_3cab03c00dbd11bc3569afa0748013f0'] =
'Inactiva';
$_MODULE['<{mercadopago}prestashop>ticketsettings_0da8d9a75492046bea7f314521e07cae'] =
'Medios de pago';
$_MODULE['<{mercadopago}prestashop>ticketsettings_958cb40bf8532bac958dd71b30867ee4'] =
'Habilita los medios de pago presenciales disponibles para tus clientes.';
$_MODULE['<{mercadopago}prestashop>ticketsettings_44fdec47036f482b68b748f9d786801b'] =
'dias';
$_MODULE['<{mercadopago}prestashop>ticketsettings_1787da92a63da5bfdf8b2aa3e7a8d54e'] =
'Vencimiento del pago';
$_MODULE['<{mercadopago}prestashop>ticketsettings_67b09091d73c254778332c4ba38c6011'] =
'En cuántos días caducarán los pagos presenciales.';
$_MODULE['<{mercadopago}prestashop>ticketsettings_5143ec2136ffd545e7aafcc9c0ce50f5'] =
' Descuento por compra';
$_MODULE['<{mercadopago}prestashop>ticketsettings_f2a22ca66322e56b52de81d06834c1e4'] =
'Ofrece un descuento especial para alentar a que tus ';
$_MODULE['<{mercadopago}prestashop>ticketsettings_474aceb7275c706995d816dc90bdf45d'] =
'clientes realicen la compra con Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>abstractpreference_e2b7dec8fa4b498156dfee6e4c84b156'] =
'Este medio de pago no está disponible';
$_MODULE['<{mercadopago}prestashop>template_1_9ab558f4124ae3f7f96ddb62799c5ae0'] =
'Diseña la mejor experiencia de pago para tus clientes';
$_MODULE['<{mercadopago}prestashop>template_1_2e2d4be43cfc9cf97f58cc59b19fe5a5'] =
'Sigue estos pasos y maximiza tu conversión:';
$_MODULE['<{mercadopago}prestashop>template_1_3972296bf88ad8b9df45219704cbc499'] =
'Obtén tus ';
$_MODULE['<{mercadopago}prestashop>template_1_d3ed68f7315b7e72b8d886b2278fcac3'] =
'credenciales ';
$_MODULE['<{mercadopago}prestashop>template_1_a74702c3f87efa59784d648c68cbe7ea'] =
'en tu cuenta de Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>template_1_afbb92a0d1285fbd49350014669046f3'] =
'Homologa tu cuenta para cobrar de forma segura a tus clientes.';
$_MODULE['<{mercadopago}prestashop>template_1_6b4fb1dba01491995d2222e8e6f59dd0'] =
'Elige los ';
$_MODULE['<{mercadopago}prestashop>template_1_b8d8952ddd5e6db1936bd51b88edc760'] =
'medios de pago ';
$_MODULE['<{mercadopago}prestashop>template_1_b52ba38c3bc63fbc7f2c36b472455143'] =
'disponibles en tu tienda.';
$_MODULE['<{mercadopago}prestashop>template_1_c6bb78598105e349729d9ebb019d739b'] =
'Activa el ';
$_MODULE['<{mercadopago}prestashop>template_1_2652eec977dcb2a5aea85f5bec235b05'] =
'entorno de pruebas Sandbox ';
$_MODULE['<{mercadopago}prestashop>template_1_3dd7c03abf4b169d72637025fad108aa'] =
'para testear tu tienda.';
$_MODULE['<{mercadopago}prestashop>template_1_05b0d76c904472532b5ab0ec235a16b8'] =
'Desactívalo si estás listo para recibir pagos.';
$_MODULE['<{mercadopago}prestashop>template_1_b3d228eb96c4d15caabb6507e9e8acba'] =
'Las credenciales son las claves que te proporcionamos para que integres de forma rápida y segura. ';
$_MODULE['<{mercadopago}prestashop>template_1_9e71c2e834abb091bae5fab9bba7754a'] =
' Debes tener una cuenta homologada en Mercado Pago para cobrar en tu sitio web. ';
$_MODULE['<{mercadopago}prestashop>template_1_5a1313cc21947818bfdbd9f5e7a3b8b6'] =
'No necesitas saber diseñar o programar para activarnos en tu tienda.';
$_MODULE['<{mercadopago}prestashop>template_1_de6b2e0f77335f7f48c28e2df309a753'] =
'Checkout de Mercado Pago';
$_MODULE['<{mercadopago}prestashop>template_1_e05dacc06bcd12a1dbc7340983ac5a03'] =
'Checkout personalizado';
$_MODULE['<{mercadopago}prestashop>template_1_055e6bd0167d88d8c87ed8e4db5b7108'] =
'Ticket checkout';
$_MODULE['<{mercadopago}prestashop>template_1_34e8683b67ce338dc5d22bd0c1958458'] =
'Prueba tu tienda';
$_MODULE['<{mercadopago}prestashop>template_1_295a38ad46665a436f94cc11ba5033ff'] =
'¿Todo configurado? Prueba tu tienda';
$_MODULE['<{mercadopago}prestashop>template_1_a2d1c5986e732ef32d7d7ec6e1c02ffb'] =
'Visita tu tienda y simula pagos para revisar que todo esté bien.';
$_MODULE['<{mercadopago}prestashop>template_1_0611191252088be4f499b8674236f3cb'] =
'Quiero testear mis ventas';
$_MODULE['<{mercadopago}prestashop>template_1_35e1af020b043e72d20163fbb8a908c2'] =
'Comienza a vender';
$_MODULE['<{mercadopago}prestashop>template_1_3aafca1b84d90601b6a86157a6cfc7fa'] =
'¡Ya saliste a producción!';
$_MODULE['<{mercadopago}prestashop>template_1_a331433d3b422894749a70f4cf957c68'] =
'Todo listo para el despegue de tus ventas. Ahora trae a tus ';
$_MODULE['<{mercadopago}prestashop>template_1_8bf0f4e736bdf1982f90e3b27a4277ab'] =
'clientes para ofrecerles la mejor experiencia de compra online con Mercado Pago. ';
$_MODULE['<{mercadopago}prestashop>template_1_a36f1b340c78e8d39d215ba65f37b3b4'] =
'Visitar mi tienda';
$_MODULE['<{mercadopago}prestashop>template_1_6eca86a8671f52bc8d9a73d1c677922c'] =
'¿Algo anda mal?';
$_MODULE['<{mercadopago}prestashop>template_1_0e6444c61d2aebf9a778787ee9322559'] =
'Ponte en contacto con nuestro soporte.';
$_MODULE['<{mercadopago}prestashop>template_1_0b50f5dd5293d9a770a6f6370fc72d0c'] =
'Tu opinión nos ayuda a mejorar';
$_MODULE['<{mercadopago}prestashop>template_1_776ad719457341aa0913807e47260a8e'] =
'Tu opinión nos ayuda a mejorar';
$_MODULE['<{mercadopago}prestashop>template_1_f27513a2f23d3c32b5dd948902ba470e'] =
'Del 1 al 10, ¿qué tan probable es que recomiendes nuestro módulo a un amigo?';
$_MODULE['<{mercadopago}prestashop>template_1_6932676695a18a04d771736f169c31dd'] =
'Nada probable';
$_MODULE['<{mercadopago}prestashop>template_1_389344a1748d5b72b78ffe1ded4df6b4'] =
'Poco probable';
$_MODULE['<{mercadopago}prestashop>template_1_97aeaf0de4598b006e47a1384a2e3646'] =
'Muy probable';
$_MODULE['<{mercadopago}prestashop>template_1_9fe6b590f9b933c4fc5acd9be20fb52e'] =
'¿Comentarios o sugerencias? Este es el espacio ideal:';
$_MODULE['<{mercadopago}prestashop>template_1_70258a400d27560f7e24fca8eb24ee48'] =
'Escribe tu comentario.';
$_MODULE['<{mercadopago}prestashop>template_1_d3d2e617335f08df83599665eef8a418'] =
'Cerrar';
$_MODULE['<{mercadopago}prestashop>template_1_94966d90747b97d1f0f206c98a8b1ac3'] =
'Enviar';
$_MODULE['<{mercadopago}prestashop>configure_ebfdf406440ec86efe63337c2190ed88'] =
'Configurar Mercado Pago ';
$_MODULE['<{mercadopago}prestashop>configure_b981586a7501c83c66f984e211a8edc1'] =
'Acerca de Mercado Pago';
$_MODULE['<{mercadopago}prestashop>configure_dbc0cd962f974e382f7dc1e5faac838a'] =
'Versión actual:';
$_MODULE['<{mercadopago}prestashop>configure_37601413631163f290129f5fe802a7ae'] =
'¿En qué país opera tu cuenta de Mercado Pago?';
$_MODULE['<{mercadopago}prestashop>configure_167ba6d3d5b002a68362baaee36759c5'] =
'Ingresa tus credenciales y elige cómo operar';
$_MODULE['<{mercadopago}prestashop>configure_03a36f89aad8dd8286bc5fe6692cbbeb'] =
'Modo Pruebas';
$_MODULE['<{mercadopago}prestashop>configure_705f67afe64f4bc771a4bf0873898ad2'] =
'Por defecto, te dejamos el entorno de pruebas (Sandbox) activo para que hagas testeos antes de empezar a vender.';
$_MODULE['<{mercadopago}prestashop>configure_53b96c3aa535ed88afe3edfaaa3e570d'] =
'Modo Producción';
$_MODULE['<{mercadopago}prestashop>configure_230755e96a95b2645824724bcb3edd36'] =
'Cuando veas que todo va bien, desactivá Sandbox para ir a Producción y abrí paso a tus ventas online.';
$_MODULE['<{mercadopago}prestashop>configure_45efbe3093b6d35ec6e43e0eb07c1503'] =
'Credenciales de Prueba';
$_MODULE['<{mercadopago}prestashop>configure_bd169ac4f12a3abfa75ea23058c2af55'] =
'Con estas claves podrás hacer las pruebas que quieras.';
$_MODULE['<{mercadopago}prestashop>configure_1cdec16cf8a4a897737cd056504193bf'] =
'Credenciales de Producción';
$_MODULE['<{mercadopago}prestashop>configure_9b397137fdf77852e7eafa8da2221520'] =
'Con estas claves podrás recibir pagos reales de tus clientes.';
$_MODULE['<{mercadopago}prestashop>configure_f4a4738ceaec1830e180c710aa5c0989'] =
'Homologa tu cuenta, solo te llevará unos minutos';
$_MODULE['<{mercadopago}prestashop>configure_ef11de888be253b9e3556a7f64703596'] =
'Completa este proceso para asegurar los datos ';
$_MODULE['<{mercadopago}prestashop>configure_5dc8a3f47c7e2cd0b5a615a568c381b6'] =
'de tus clientes y la adecuación a las normas o ';
$_MODULE['<{mercadopago}prestashop>configure_5bfd14259acc34028aef59bae1296993'] =
'disposiciones legales de cada país.  ';
$_MODULE['<{mercadopago}prestashop>configure_2401b8d430cf1acf0427302580d9478d'] =
'Homologar mi cuenta';
$_MODULE['<{mercadopago}prestashop>configure_80a11d2a54a677f6fadd9c041c0d6b98'] =
'Información de tu tienda';
$_MODULE['<{mercadopago}prestashop>configure_024eb7a83d8dec5f53ef18d2cc24c42a'] =
'Ingresa los datos de tu negocio en el módulo:';
$_MODULE['<{mercadopago}prestashop>configure_cdd96fbd5af791ea36d0eab3b5c0cbcc'] =
'¿Eres partner de Mercado Pago?';
$_MODULE['<{mercadopago}prestashop>configure_418ea206bf7c7ec9d85e436517446d90'] =
'Ofrece todos los medios de pago.';
$_MODULE['<{mercadopago}prestashop>configure_a823edeec9a893e526be44211b11dd21'] =
'Experiencia de pago en el sitio de Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>configure_ba409932f82a5dbbc411b83fe3e8adb7'] =
'Tus clientes pueden pagar como invitados o ingresando a su cuenta de Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>configure_edcc027aee641dec9c6e6cfa70aede7d'] =
'Haz que tu cliente termine su compra con estos ajustes básicos:';
$_MODULE['<{mercadopago}prestashop>configure_0da8d9a75492046bea7f314521e07cae'] =
'Selecciona tarjetas';
$_MODULE['<{mercadopago}prestashop>configure_24e9fd6116bb8c7c0f060273672067e2'] =
'Selecciona pagos personales';
$_MODULE['<{mercadopago}prestashop>configure_c70ec5b31b31ecef0efd3ea40e33909f'] =
'Configuración avanzada';
$_MODULE['<{mercadopago}prestashop>configure_18b934da2943766913dc95ae10cd11d9'] =
'Activa otras herramientas de nuestro módulo listas para usar.';
$_MODULE['<{mercadopago}prestashop>configure_1bc20b46625d14ce9a7587faf7af4171'] =
'Ofrece pagos con tarjetas de débito y crédito.';
$_MODULE['<{mercadopago}prestashop>configure_7e3c0f9991ae9abe60ee5e022ae42159'] =
'Experiencia de pago dentro de tu tienda. ';
$_MODULE['<{mercadopago}prestashop>configure_6e7cc3c1db795bffb2de3a237442e047'] =
'Tus clientes pagan como invitados sin salir de tu tienda.';
$_MODULE['<{mercadopago}prestashop>configure_2cf04dc84eb55a15d6557f1f30eb63ad'] =
'Ofrece pagos en efectivo.';
$_MODULE['<{mercadopago}prestashop>configure_9816529bd797ea2cf8c0dfe7b13b9dd2'] =
'Tus clientes pagan como invitados sin salir de tu tienda.';
$_MODULE['<{mercadopago}prestashop>template_2_d6cf1a3115755104888673a6b9e3acf6'] =
'Despega tus ventas online.';
$_MODULE['<{mercadopago}prestashop>template_2_0275de4d9b97b8b6c73adf434500771c'] =
'Ofrece a tus clientes la mejor';
$_MODULE['<{mercadopago}prestashop>template_2_a04c73627fe84661558c0cca42df4dcf'] =
'experiencia de pago.';
$_MODULE['<{mercadopago}prestashop>template_2_984641c8c6d6a5ccfe1c7b70902efbed'] =
'Configura Mercado Pago en tu tienda';
$_MODULE['<{mercadopago}prestashop>template_2_9a59fbee87ac663ed34c1ad8552cdd28'] =
'Muestra tus promociones ';
$_MODULE['<{mercadopago}prestashop>template_2_ba78227f84b4f2f3b63369ff466fde28'] =
'y vende en cuotas con ';
$_MODULE['<{mercadopago}prestashop>template_2_2f3dcea44606632f4c34ddde2bb2cda7'] =
'la mejor financiación posible.';
$_MODULE['<{mercadopago}prestashop>template_2_2222376e726e3e241627eae36bc3dae5'] =
'Te cobraremos una comisión de cada pago que recibas.';
$_MODULE['<{mercadopago}prestashop>template_2_34497fd2ef216c6ae8702b540a345a6f'] =
'¿Cuáles son los beneficios de ';
$_MODULE['<{mercadopago}prestashop>template_2_07156bcf3b3864f373f3e3f78eac9113'] =
'cobrar con Mercado Pago?';
$_MODULE['<{mercadopago}prestashop>template_2_909e19c722cf2bd12064190b5bd146c6'] =
'Cobra como quieras y vende sin límites.';
$_MODULE['<{mercadopago}prestashop>template_2_8ef62d890ae454308fa0cb6c12125437'] =
'Maximiza tu conversión con ';
$_MODULE['<{mercadopago}prestashop>template_2_1dbee053eebd52c8c4d8abcdcca52a04'] =
'la mejor experiencia de pago.';
$_MODULE['<{mercadopago}prestashop>template_2_d6589ce85c5eef9eeafe406a11cf6713'] =
'Tienes herramientas listas para usar y ';
$_MODULE['<{mercadopago}prestashop>template_2_399c1f7ea114e0a5d6c6a4e66783e4db'] =
'especialistas dispuestos a ayudarte. ';
$_MODULE['<{mercadopago}prestashop>template_2_8254e152eb98ce090be059e2d40a2bc7'] =
'¿Cómo recibo los pagos?';
$_MODULE['<{mercadopago}prestashop>template_2_7998c642e7e2568b4d748a5923d497aa'] =
'Tus clientes pagan como ellos prefieran.';
$_MODULE['<{mercadopago}prestashop>template_2_2c1d1e4f152962e02d1151957f33c8bf'] =
'Se acredita ';
$_MODULE['<{mercadopago}prestashop>template_2_a59d3d544ff6983c0877ea5caa16a2b0'] =
'el dinero en tu cuenta de Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>template_2_e9299886340fc65e2c7e42bb64ebb0e1'] =
'Una vez disponible, ';
$_MODULE['<{mercadopago}prestashop>template_2_22c9f9da706bfe8c6735a88b486970c0'] =
'lo transfieres sin costo adicional a tu cuenta bancaria.';
$_MODULE['<{mercadopago}prestashop>template_2_aa94393365aa5eae33a504e61457d447'] =
'¿Qué puedo hacer con ';
$_MODULE['<{mercadopago}prestashop>template_2_987d06b272f6a80ae2fad5f18c1b2524'] =
'Mercado Pago en mi tienda?';
$_MODULE['<{mercadopago}prestashop>template_2_f50c11299b7ea4211969944cda8ece2f'] =
'Compra con un clic:';
$_MODULE['<{mercadopago}prestashop>template_2_e99a5c379a69fa1eb41aef11c97f8a62'] =
' recordamos los datos de tus usuarios logueados.';
$_MODULE['<{mercadopago}prestashop>template_2_6b8816b3ebd85760ccbe3535518f5628'] =
'Pago como invitado: ';
$_MODULE['<{mercadopago}prestashop>template_2_d3f293f60d44a9099d36b93bd1c71ee3'] =
'no hace falta que tus clientes abran una cuenta en Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>template_2_d2f7e9781e7c0d7d50d8a5247dff453c'] =
'Devolución de pagos y ';
$_MODULE['<{mercadopago}prestashop>template_2_388ac0bf13986abefe449b83a0cbda0e'] =
'cancelación de pagos pendientes.';
$_MODULE['<{mercadopago}prestashop>template_2_89f716cae37270d25f9c4d1664eb10fc'] =
'Crecer está en tus manos. ';
$_MODULE['<{mercadopago}prestashop>template_2_c8e43776845c4374c26c305c36f6460f'] =
'Ofrece a tus clientes';
$_MODULE['<{mercadopago}prestashop>template_2_105ceb4f9d70cd97123fdb2bfceb8a2a'] =
'una experiencia de pago única. ';
$_MODULE['<{mercadopago}prestashop>template_2_bb0a503f6022dd9ad15e450f25480f8b'] =
'Somos partners oficiales de Prestashop';
$_MODULE['<{mercadopago}prestashop>template_2_f8e3823fce704473f01e4781d07bf917'] =
'Programa de Protección de vendedores.';
$_MODULE['<{mercadopago}prestashop>failure_55d37c0a3c1b32de6e3f9ceb1f8c0a4a'] =
' ¡Ops! Ha ocurrido un error en su pago, intente nuevamente...	';
$_MODULE['<{mercadopago}prestashop>custom_bbfe522e4f1486075b15c60e603fee6d'] =
'Paga con tarjetas de crédito y débito';
$_MODULE['<{mercadopago}prestashop>custom_b2fd5a4f417785d2c8d5a3674a1b3e83'] =
'¿Con qué tarjetas puedo pagar?';
$_MODULE['<{mercadopago}prestashop>custom_e7f9e382dc50889098cbe56f2554c77b'] =
'Tarjeta de crédito';
$_MODULE['<{mercadopago}prestashop>custom_87aed576797f8992ddc7a8c629fb7035'] =
'Tarjeta de débito';
$_MODULE['<{mercadopago}prestashop>custom_e4179c3a6980bed5071fe92c929e6157'] =
'Ingresa los datos de tu tarjeta';
$_MODULE['<{mercadopago}prestashop>custom_a44217022190f5734b2f72ba1e4f8a79'] =
'Número de tarjeta';
$_MODULE['<{mercadopago}prestashop>custom_00cc96b2cd5db9825852af3700813e4e'] =
'Número de la tarjeta inválido';
$_MODULE['<{mercadopago}prestashop>custom_bab78a96a00725b7efa6f34f452d17b9'] =
'Nombre y apellido del titular de la tarjeta';
$_MODULE['<{mercadopago}prestashop>custom_ae35ed084114b30399338fa515188bcb'] =
'Código de seguridad inválido';
$_MODULE['<{mercadopago}prestashop>custom_8c1279db4db86553e4b9682f78cf500e'] =
'Fecha de vencimiento';
$_MODULE['<{mercadopago}prestashop>custom_22d248eda08203b9ebb7b84ca22635cb'] =
'Fecha de expiración de la tarjeta inválida';
$_MODULE['<{mercadopago}prestashop>custom_792bb28aea0e109daf741be7eb18ec87'] =
'Código de seguridad';
$_MODULE['<{mercadopago}prestashop>custom_60a104dc50579d60cbc90158fada1dcf'] =
'CVV';
$_MODULE['<{mercadopago}prestashop>custom_b905fb66f717edccb30cb861bc1f20f0'] =
'Últimos 3 números que figuran en el';
$_MODULE['<{mercadopago}prestashop>custom_f8809653e0184b71678421dc963074c7'] =
'¿En cuántas cuotas quieres pagar?';
$_MODULE['<{mercadopago}prestashop>custom_16bfdf30b1a694ab3bf3da553a4dff03'] =
'Banco emisor';
$_MODULE['<{mercadopago}prestashop>custom_2aeaeb22ad892fd719ccde8e3d55617d'] =
'Ingresa tu número de documento';
$_MODULE['<{mercadopago}prestashop>custom_a1fa27779242b4902f7ae3bdd5c6d508'] =
'Tipo';
$_MODULE['<{mercadopago}prestashop>custom_14c44ffb79e2c416100024bd491b48b9'] =
'Número de documento';
$_MODULE['<{mercadopago}prestashop>custom_e5ef874bb07f7b149fd67a72e713d624'] =
'Solo número';
$_MODULE['<{mercadopago}prestashop>custom_9abfb506bebd1e72069f0be0014986dc'] =
'Número de documento inválido';
$_MODULE['<{mercadopago}prestashop>custom_ab8a2170eb587c1022ad4ee33eb99e7f'] =
'Completa todos los campos, ¡son obligatorios!';
$_MODULE['<{mercadopago}prestashop>custom_377e99e7404b414341a9621f7fb3f906'] =
'Finalizar';
$_MODULE['<{mercadopago}prestashop>custom_961f2247a2070bedff9f9cd8d64e2650'] =
'Elegir';
$_MODULE['<{mercadopago}prestashop>standard_e7f9e382dc50889098cbe56f2554c77b'] =
'Tarjetas de Crédito';
$_MODULE['<{mercadopago}prestashop>standard_26f5a22330a8d5d32c87e6a4c7f3de95'] =
'Hasta';
$_MODULE['<{mercadopago}prestashop>standard_7d41ca7af6f495d8e3432f8a4544f253'] =
'cuotas';
$_MODULE['<{mercadopago}prestashop>standard_87aed576797f8992ddc7a8c629fb7035'] =
'Tarjetas de Débito';
$_MODULE['<{mercadopago}prestashop>standard_95428f32e5c696cf71baccb776bc5c15'] =
'Transferencia bancaria';
$_MODULE['<{mercadopago}prestashop>standard_a4742458d37df9c6a26f9c99ed8bcb3f'] =
'Te llevamos a nuestro sitio para completar el pago';
$_MODULE['<{mercadopago}prestashop>ticket_return_24a4e89cbe1fdf5548035b98660db505'] =
'Gracias por su compra! Estamos a la espera del pago.';
$_MODULE['<{mercadopago}prestashop>ticket_return_21d104a54fc71a19a325c7305327f1d2'] =
'Processing...	';
$_MODULE['<{mercadopago}prestashop>ticket_return_051b4fc3b5b94694296b17af2f969dfc'] =
'Imprimir';
$_MODULE['<{mercadopago}prestashop>custom_dc4554b3840d99f5489a30a49f9477b4'] =
'Ver promociones vigentes';
$_MODULE['<{mercadopago}prestashop>ticket_2aeaeb22ad892fd719ccde8e3d55617d'] =
'Ingresa tu número de documento';
$_MODULE['<{mercadopago}prestashop>ticket_a1fa27779242b4902f7ae3bdd5c6d508'] =
'Tipo';
$_MODULE['<{mercadopago}prestashop>ticket_3ba0f40775d6d6ace27ef929f5be3cdf'] =
'CI';
$_MODULE['<{mercadopago}prestashop>ticket_14c44ffb79e2c416100024bd491b48b9'] =
'Número de documento';
$_MODULE['<{mercadopago}prestashop>ticket_2dd4472245a696bc0b4b944db2a8b519'] =
'Persona física';
$_MODULE['<{mercadopago}prestashop>ticket_5a4471420aa5026337a78145a7f97b63'] =
'Persona jurídica';
$_MODULE['<{mercadopago}prestashop>ticket_d4150c6bd6a42bda6fc0bcc118cafd41'] =
'Nombre';
$_MODULE['<{mercadopago}prestashop>ticket_4e1d2b56da5ef5d0c57afc363cb790d8'] =
'Documento';
$_MODULE['<{mercadopago}prestashop>ticket_165613bac50ccc224e149a310147a944'] =
' Debes informar tu nombre';
$_MODULE['<{mercadopago}prestashop>ticket_77587239bf4c54ea493c7033e1dbf636'] =
'Apellido';
$_MODULE['<{mercadopago}prestashop>ticket_515003ca1a070566016e4ac6312097da'] =
' Debes informar el apellido';
$_MODULE['<{mercadopago}prestashop>ticket_e3fe6d057f44794ab6098de4ada86d80'] =
'CPF	';
$_MODULE['<{mercadopago}prestashop>ticket_c64553750fa9a18283d45c328cdf7411'] =
'CNPJ';
$_MODULE['<{mercadopago}prestashop>ticket_4486ead55880d17a0d1fec8e90dd1783'] =
' El documento debe ser valido';
$_MODULE['<{mercadopago}prestashop>ticket_dd7bf230fde8d4836917806aff6a6b27'] =
'Dirección';
$_MODULE['<{mercadopago}prestashop>ticket_e38b9b2c9db79347219f907478d3181d'] =
'Debes informar la dirección';
$_MODULE['<{mercadopago}prestashop>ticket_b2ee912b91d69b435159c7c3f6df7f5f'] =
'Número';
$_MODULE['<{mercadopago}prestashop>ticket_21aba1a06a9c8a7375da5f69a8a24025'] =
'Debes informar el número de dirección';
$_MODULE['<{mercadopago}prestashop>ticket_57d056ed0984166336b7879c2af3657f'] =
'Ciudad';
$_MODULE['<{mercadopago}prestashop>ticket_46a2a41cc6e552044816a2d04634545d'] =
'Estado';
$_MODULE['<{mercadopago}prestashop>ticket_383f23791705084d1189869ac40ca9c5'] =
'Selecciona el estado';
$_MODULE['<{mercadopago}prestashop>ticket_f8b1b7cee36ca4abc72a9edbbece60dc'] =
' Debes informar al estado';
$_MODULE['<{mercadopago}prestashop>ticket_25f75488c91cb6c3bab92672e479619f'] =
'Código postal';
$_MODULE['<{mercadopago}prestashop>ticket_4c86644753757af0f7b40840ddb76762'] =
'Debes informar el código postal';
$_MODULE['<{mercadopago}prestashop>ticket_7ed938d13683ef13343362a05226f0e9'] =
'Completa todos los campos, ¡son obligatorios!';
$_MODULE['<{mercadopago}prestashop>ticket_04cf30c71ec29aee2615e8cd526afeef'] =
'Por favor, selecciona el emisor de pagos presenciales con el que quieras hacer la compra: ';
$_MODULE['<{mercadopago}prestashop>standard_3e8bd808fa886bce4b3de20f28870f9d'] =
'Quiero pagar con Mercado Pago sin costo adicional.';
$_MODULE['<{mercadopago}prestashop>standard_d80b215711d6701ab5dae0b8171f4da3'] =
'Usa el medio de pago que prefieras.';
$_MODULE['<{mercadopago}prestashop>ticket_5edffb5efe684d534217bad198adeece'] =
'Paga con medios de pago en efectivo';
$_MODULE['<{mercadopago}prestashop>ticket_49ee3087348e8d44e1feda1917443987'] =
'Nombre';
$_MODULE['<{mercadopago}prestashop>ticket_377e99e7404b414341a9621f7fb3f906'] =
'Finalizar';
$_MODULE['<{mercadopago}prestashop>mpapi_052dbe4cbe0fc4c37bbb5c59f70ac2d4'] =
'El medio de pago no es válido o no está disponible.';
$_MODULE['<{mercadopago}prestashop>mpapi_9fdd961e41fdff842c80aea4a875138d'] =
'El monto de transacción no puede ser procesado por Mercado Pago.';
$_MODULE['<{mercadopago}prestashop>mpapi_8a6cb9e19e687968bffd11566895bb00'] =
'Posibles causas: Moneda no soportada; ';
$_MODULE['<{mercadopago}prestashop>mpapi_81e3267deaa45a720e31c55e53d45d95'] =
'Montos por debajo del mínimo o por encima del máximo permitido.';
$_MODULE['<{mercadopago}prestashop>mpapi_8a0595f24ba7e98096ea2f52d1546605'] =
'Los usuários no son válidos. Posibles causas: ';
$_MODULE['<{mercadopago}prestashop>mpapi_edf9cda9340f50dce8b4dad690c68341'] =
'Comprador y vendedor tienen la misma cuenta en Mercado Pago; ';
$_MODULE['<{mercadopago}prestashop>mpapi_5f65da2a91e569c0f6c8821a8f354cf3'] =
'La transacción involucrando usuários de producción y de prueba.';
$_MODULE['<{mercadopago}prestashop>mpapi_c92a089d8ab502e6ff18d8bf1c724833'] =
'Uso no autorizado de credenciales de producción.';
$_MODULE['<{mercadopago}prestashop>mpapi_ac7495823e9778d3ffc7677ac5d3765a'] =
'Posibles causas: Pendencia de permiso de uso en producción para la credencial del vendedor.';
$_MODULE['<{mercadopago}prestashop>payment_return_3e09b7a997278261b6db524197e20bf8'] =
'Gracias por su compra!';
$_MODULE['<{mercadopago}prestashop>payment_return_21d104a54fc71a19a325c7305327f1d2'] =
'Procesando...';
$_MODULE['<{mercadopago}prestashop>payment_return_051b4fc3b5b94694296b17af2f969dfc'] =
'Imprimir';
$_MODULE['<{mercadopago}prestashop>payment_return_deb10517653c255364175796ace3553f'] =
'Producto';
$_MODULE['<{mercadopago}prestashop>payment_return_3601146c4e948c32b6424d2c0a7f0118'] =
'Precio';
$_MODULE['<{mercadopago}prestashop>payment_return_03ab340b3f99e03cff9e84314ead38c0'] =
'Cantidad';
$_MODULE['<{mercadopago}prestashop>payment_return_2194aaec8cc7086ab0e93f74547e5f53'] =
'Subtotal';
$_MODULE['<{mercadopago}prestashop>payment_return_104d9898c04874d0fbac36e125fa1369'] =
'Descuento';
$_MODULE['<{mercadopago}prestashop>payment_return_ea9cf7e47ff33b2be14e6dd07cbcefc6'] =
'Envío y manejo';
$_MODULE['<{mercadopago}prestashop>payment_return_3af22b59f4641bc5501998297f9ac70d'] =
'TOTAL';
